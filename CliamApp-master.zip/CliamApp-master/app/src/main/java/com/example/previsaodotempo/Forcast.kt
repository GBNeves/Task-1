package com.example.previsaodotempo

class Forecast {
    var date: String = ""
    var weekday: String = ""
    var max: Int = 0
    var min: Int = 0
    var description: String = ""
    var condition: String  = ""
}
